#!/usr/bin/env python3
import sys
import os

import getpass

# 确保脚本位于固定目录，防止相对路径问题
EXPECTED_DIR = "/data/project/linux_tc"
script_dir = os.path.dirname(os.path.abspath(__file__))
if script_dir != EXPECTED_DIR:
    print(f"[路径错误] 本脚本必须位于 {EXPECTED_DIR}，当前路径: {script_dir}", file=sys.stderr)
    sys.exit(1)

if os.geteuid() != 0:
    user = getpass.getuser()
    print(f"[权限错误] 当前用户: {user}\n本脚本需要 root 权限，请使用 sudo 或以 root 用户运行。\n示例: sudo python3 {sys.argv[0]}", file=sys.stderr)
    sys.exit(1)

def get_os_info():
    """获取 /etc/os-release 信息，返回字典"""
    try:
        with open('/etc/os-release', 'r') as f:
            lines = f.readlines()
        os_info = {}
        for line in lines:
            if '=' in line:
                k, v = line.strip().split('=', 1)
                os_info[k] = v.strip('"')
        return os_info
    except Exception:
        return {}

def is_debian_based(os_info):
    """检测系统是否为 Debian 系列"""
    id_like = os_info.get('ID_LIKE', '').lower()
    os_id = os_info.get('ID', '').lower()
    if 'debian' in id_like or 'debian' in os_id:
        return True
    else:
        return False

os_info = get_os_info()
if not is_debian_based(os_info):
    print("[系统检测失败] 当前系统信息如下：")
    print(f"  ID      : {os_info.get('ID', '未知')}")
    print(f"  ID_LIKE : {os_info.get('ID_LIKE', '未知')}")
    print("本脚本仅支持 Debian 系列 Linux 发行版，如 Debian/Ubuntu/Deepin 等。\n请在受支持的系统上运行。", file=sys.stderr)
    sys.exit(1)

print("[系统检测通过]")
print(f"  当前系统: {os_info.get('NAME', os_info.get('ID', '未知'))}")
print(f"  版本    : {os_info.get('VERSION', '未知')}")
print("可以继续后续操作……")

import subprocess
import re
import json
import yaml

# -------- 颜色支持 --------
try:
    from colorama import Fore, Style, init as colorama_init
    colorama_init(autoreset=True)

    def colored(text, color):
        return getattr(Fore, color.upper(), "") + str(text) + Style.RESET_ALL
except ImportError:
    # 如果 colorama 未安装，退化为普通文本
    def colored(text, color):
        return str(text)

def get_interfaces():
    # 只列出物理网卡（排除lo和虚拟设备）
    try:
        interfaces = []
        with open('/proc/net/dev') as f:
            for line in f.readlines()[2:]:
                name = line.split(':')[0].strip()
                if name and not name.startswith(('lo', 'ifb', 'docker', 'veth', 'br-')):
                    interfaces.append(name)
        return interfaces
    except Exception:
        return []

def select_interface(allow_ifb: bool = False):
    """交互式选择网卡。

    allow_ifb: 为 True 时，将 ifb0 也加入可选列表（查询功能需要）。"""
    interfaces = get_interfaces()
    if allow_ifb and os.path.exists('/sys/class/net/ifb0'):
        interfaces.append('ifb0')
    if not interfaces:
        print("未检测到可用网卡。\n")
        return None
    print(colored("可用网卡列表：", "cyan"))
    for idx, iface in enumerate(interfaces, 1):
        print(f"  {idx}. {iface}")
    while True:
        sel = input("请输入要操作的网卡编号：").strip()
        if sel.isdigit() and 1 <= int(sel) <= len(interfaces):
            return interfaces[int(sel)-1]
        else:
            print("无效选择，请重新输入。\n")

def convert_rate_to_mbps(rate):
    """将tc速率转换为Mbps数值"""
    if not rate:
        return "0"
    if rate.endswith("Mbit"):
        return rate[:-4]
    elif rate.endswith("mbit"):
        return rate[:-4]
    elif rate.endswith("Kbit"):
        return str(round(float(rate[:-4]) / 1000, 1))
    elif rate.endswith("kbit"):
        return str(round(float(rate[:-4]) / 1000, 1))
    return rate

def get_root_rate(iface):
    """获取总限速速率，从 class htb 1:1 中查找，因为这是总限速的实际位置"""
    try:
        class_out = subprocess.check_output(["tc", "class", "show", "dev", iface], encoding="utf-8")
    except subprocess.CalledProcessError:
        return None

    for line in class_out.splitlines():
        if "class htb 1:1 " in line:
            match = re.search(r"rate\s+([\w\d]+)", line)
            if match:
                return match.group(1)
    return None

def get_classes(iface):
    """获取指定网卡的分类信息，包括过滤器"""
    try:
        class_out = subprocess.check_output(["tc", "class", "show", "dev", iface], encoding="utf-8")
    except subprocess.CalledProcessError:
        print("  [!] 获取 class 失败")
        class_out = ""
    classes = []
    for line in class_out.splitlines():
        if "class htb" in line:
            parts = line.split()
            if len(parts) > 2:
                classid = parts[2]
                if classid != "1:1" and classid.startswith("1:"):
                    rate = None
                    for i, p in enumerate(parts):
                        if p == "rate" and i+1 < len(parts):
                            rate = parts[i+1]
                    
                    # 获取该分类的过滤器
                    filters = get_filters(iface, classid)
                    class_info = {"classid": classid, "rate": rate}
                    if filters:
                        class_info["filters"] = filters
                    
                    classes.append(class_info)
    return classes

def show_tc_rules_simple():
    """简易查询模式，适合非技术用户，同时显示系统状态和配置文件状态"""
    iface = select_interface(allow_ifb=True)
    if not iface:
        return
    print(f"\n[{iface}] 当前限速设置：")
    root_rate = get_root_rate(iface)
    if root_rate:
        print(f"• 总限速：{convert_rate_to_mbps(root_rate)} Mbps")
    else:
        print("• 总限速：未设置")
    
    # 先从配置文件读取规则，友好展示 name 字段（可含端口段），避免枚举过长列表
    cfg = read_yaml_config()
    cfg_rule = next((r for r in cfg.get("rules", []) if r.get("iface") == iface), None)
    if cfg_rule and cfg_rule.get("classes"):
        print(f"• 配置文件共定义 {len(cfg_rule['classes'])} 条端口限速规则:")
        for cls in cfg_rule["classes"]:
            name_field = cls.get("name", "")
            rate_str = cls.get("rate", "")
            # 解析协议部分，美化显示
            if "@" in name_field:
                port_part, proto_part = name_field.split("@", 1)
            else:
                port_part, proto_part = name_field, "tcpudp"
            proto_display = proto_part.upper()
            if proto_part == "tcpudp":
                proto_display = "TCP+UDP"
            print(f"  * 端口 {port_part} ({proto_display}): 限速 {convert_rate_to_mbps(rate_str)} Mbps")
    else:
        print("• 配置文件中未找到针对该网卡的端口限速规则")

    # 依旧获取系统分类，用于检测缺失规则，但不全部枚举输出
    classes = get_classes(iface)
    if classes:
        total_ports = sum(len(get_filters(iface, c["classid"])) if "filters" in c else 1 for c in classes)
        print(f"• 系统中已设置 {len(classes)} 个分类，共 {total_ports} 个端口过滤规则")
        filter_count = 0
        for cls in classes:
            if cls.get("filters"):
                for f in cls["filters"]:
                    filter_count += 1
                    proto = f.get("protocol", "TCP").upper()
                    port = f.get("port", "未知")
                    rate = convert_rate_to_mbps(cls.get("rate", "未知"))
                    print(f"  * 端口 {port} ({proto}): 限速 {rate} Mbps")
        if filter_count == 0:
            print("  无具体端口限速规则")
    else:
        print("• 系统中未设置分类限速规则")
    
    # 从配置文件获取信息，并检查是否有未应用的规则
    config = read_yaml_config()
    config_rule = None
    for rule in config.get("rules", []):
        if rule.get("iface") == iface:
            config_rule = rule
            break
    
    if config_rule:
        config_filters = []
        for cls in config_rule.get("classes", []):
            if cls.get("filters"):
                for f in cls["filters"]:
                    f["classid"] = cls["classid"]
                    config_filters.append(f)
        
        # 检查系统中的过滤器是否都存在于配置文件中
        system_filters = []
        for cls in classes:
            if cls.get("filters"):
                for f in cls["filters"]:
                    # 确保协议值正确处理
                    protocol = f.get("protocol", "tcp")
                    if isinstance(protocol, str):
                        protocol = protocol.lower()
                    system_filters.append((f.get("port"), protocol, cls["classid"]))
        
        # 确保配置文件中的协议值正确处理
        config_filters_set = set()
        for f in config_filters:
            protocol = f.get("protocol", "tcp")
            if isinstance(protocol, str):
                protocol = protocol.lower()
            config_filters_set.add((f.get("port"), protocol, f.get("classid")))
            
        system_filters_set = set(system_filters)
        
        missing_filters = config_filters_set - system_filters_set
        if missing_filters:
            for port, proto, classid in missing_filters:
                print(f"  [警告] 配置文件中的端口 {port} ({proto.upper()}) 限速规则未应用到系统")
    else:
        if iface.startswith("ifb"):
            print(f"• {iface} 由脚本自动管理，配置文件中不会出现相应条目")
        else:
            print(f"• 配置文件中未找到针对 {iface} 的配置")

def extract_rate_from_class_line(line):
    """从tc class输出行中提取速率信息"""
    parts = line.split()
    rate = "unknown"
    ceil = "unknown"
    for i, p in enumerate(parts):
        if p == "rate" and i+1 < len(parts):
            rate = parts[i+1]
        if p == "ceil" and i+1 < len(parts):
            ceil = parts[i+1]
    return f"{rate} (ceil: {ceil})"

def show_tc_rules_advanced():
    """专业查询模式，显示详细技术信息，同时显示系统状态和配置文件状态"""
    iface = select_interface(allow_ifb=True)
    if not iface:
        return
    print(f"\n[{iface}] 当前限速规则（详细模式）：")
    
    # 获取系统qdisc信息
    try:
        qdisc_out = subprocess.check_output(["tc", "qdisc", "show", "dev", iface], encoding="utf-8")
        print("• 系统队列规则 (qdisc):")
        for line in qdisc_out.splitlines():
            if line.strip():
                print(f"  - {line.strip()}")
    except subprocess.CalledProcessError:
        print("  [!] 获取 qdisc 失败")
    
    # 获取总限速
    root_rate = get_root_rate(iface)
    if root_rate:
        print(f"• 系统总限速 (root class 1:1): {root_rate}")
    else:
        print("• 系统总限速：未设置")
    
    # 从配置文件获取总限速
    config = read_yaml_config()
    config_rule = None
    for rule in config.get("rules", []):
        if rule.get("iface") == iface:
            config_rule = rule
            break
    if config_rule and config_rule.get("root_rate"):
        print(f"• 配置文件总限速: {config_rule['root_rate']}")
    else:
        print(f"• 配置文件总限速: 未设置")
    
    # 获取系统中的分类和过滤器
    classes = get_classes(iface)
    if classes:
        print("\n• 系统子分类限速规则:")
        for cls in classes:
            classid = cls.get('classid', '未知')
            rate = cls.get('rate', '未知')
            print(f"  - 分类 {classid}: {rate}")
            if cls.get("filters"):
                for f in cls["filters"]:
                    port = f.get("port", "未知")
                    proto = f.get("protocol", "tcp").upper()
                    print(f"    → 端口 {port} ({proto}) 流量映射到此分类")
            else:
                print(f"    → 无过滤器关联到此分类")
    else:
        print("\n• 系统子分类限速规则: 未设置")
    
    # 显示详细的过滤器配置
    try:
        filter_out = subprocess.check_output(["tc", "filter", "show", "dev", iface], encoding="utf-8")
        print("\n• 详细过滤器配置:")
        current_filter = None
        for line in filter_out.splitlines():
            line = line.strip()
            if not line:
                continue
            if line.startswith("filter parent"):
                current_filter = line
                print(f"  - {line}")
            elif current_filter:
                print(f"    {line}")
    except subprocess.CalledProcessError:
        print("  [!] 获取 filter 失败")
    
    # 检查配置文件与系统状态是否一致
    if config_rule:
        config_filters = []
        for cls in config_rule.get("classes", []):
            if cls.get("filters"):
                for f in cls["filters"]:
                    f["classid"] = cls["classid"]
                    config_filters.append(f)
        
        # 检查系统中的过滤器是否都存在于配置文件中
        system_filters = []
        for cls in classes:
            if cls.get("filters"):
                for f in cls["filters"]:
                    system_filters.append( (f.get("port"), f.get("protocol", "tcp").lower(), cls["classid"]) )
        
        config_filters_set = set([(f.get("port"), f.get("protocol", "tcp").lower(), f.get("classid")) for f in config_filters])
        system_filters_set = set(system_filters)
        
        missing_filters = config_filters_set - system_filters_set
        if missing_filters:
            print("\n• 警告：以下配置文件中的规则未应用到系统:")
            for port, proto, classid in missing_filters:
                print(f"  * 端口 {port} ({proto.upper()}) 关联到分类 {classid}")
    else:
        if iface.startswith("ifb"):
            print(f"\n• {iface} 由脚本自动管理，配置文件中不会出现相应条目")
        else:
            print(f"\n• 配置文件中未找到针对 {iface} 的配置")

def get_filters(iface, classid):
    """获取指定网卡和分类的过滤器信息，使用正则表达式提高解析准确性"""
    try:
        filter_out = subprocess.check_output(["tc", "filter", "show", "dev", iface], encoding="utf-8")
    except subprocess.CalledProcessError:
        return []

    filters = []
    # 正则表达式，用于匹配协议和端口
    # 匹配协议 (tcp=6, udp=17)
    proto_re = re.compile(r"match (?:0006|0011)0000/ffff0000")
    # 匹配目标端口 (e.g., match 00001f90/0000ffff at 2)
    dport_re = re.compile(r"match 0000([0-9a-f]{4})/0000ffff(?: at 2)?")
    # 匹配源端口 (e.g., match 1f900000/ffff0000 at 2)
    sport_re = re.compile(r"match ([0-9a-f]{4})0000/ffff0000(?: at 2)?")

    # 将输出按过滤器块分割
    filter_blocks = filter_out.split("filter parent")

    for block in filter_blocks:
        if not block.strip() or f"flowid {classid}" not in block:
            continue

        lines = block.strip().splitlines()
        filter_info = {"classid": classid}
        port = None
        protocol = "tcp"  # 默认为tcp

        for line in lines:
            line = line.strip()
            # 确定协议
            if "protocol 6" in line or "ip protocol 6" in line or "match 00060000/00ff0000" in line:
                protocol = "tcp"
            elif "protocol 17" in line or "ip protocol 17" in line or "match 00110000/00ff0000" in line:
                protocol = "udp"

            # 确定端口
            dport_match = dport_re.search(line)
            if dport_match:
                port = str(int(dport_match.group(1), 16))
                continue

            sport_match = sport_re.search(line)
            if sport_match:
                port = str(int(sport_match.group(1), 16))
                continue

        if port:
            # 按 (port, protocol) 去重，避免同一端口的 sport/dport 记录重复
            key = (port, protocol)
            if key not in {(f.get("port"), f.get("protocol")) for f in filters}:
                filter_info["port"] = port
                filter_info["protocol"] = protocol
                filters.append(filter_info)

    return filters

def get_classes(iface):
    """获取指定网卡的分类信息，包括过滤器"""
    try:
        class_out = subprocess.check_output(["tc", "class", "show", "dev", iface], encoding="utf-8")
    except subprocess.CalledProcessError:
        print("  [!] 获取 class 失败")
        class_out = ""
    classes = []
    for line in class_out.splitlines():
        if "class htb" in line:
            parts = line.split()
            if len(parts) > 2:
                classid = parts[2]
                if classid != "1:1" and classid.startswith("1:"):
                    rate = None
                    for i, p in enumerate(parts):
                        if p == "rate" and i+1 < len(parts):
                            rate = parts[i+1]
                    
                    # 获取该分类的过滤器
                    filters = get_filters(iface, classid)
                    class_info = {"classid": classid, "rate": rate}
                    if filters:
                        class_info["filters"] = filters
                    
                    classes.append(class_info)
    return classes

def read_yaml_config():
    """读取最新格式的 YAML 配置，返回 dict。如果文件不存在或格式非法则返回{"rules": []}."""
    try:
        with open("config.yaml", "r", encoding="utf-8") as f:
            data = yaml.safe_load(f) or {}
            if not isinstance(data, dict) or "rules" not in data:
                return {"rules": []}
            # 保证有 rules 键
            data.setdefault("rules", [])
            return data
    except FileNotFoundError:
        return {"rules": []}
    except yaml.YAMLError as e:
        print(f"[YAML 解析错误] {e}")
        return {"rules": []}
    """读取YAML配置文件，返回完整的配置对象"""
    try:
        with open("config.yaml", "r") as f:
            lines = f.readlines()
            if not lines or not lines[0].strip() == "rules:":
                return {"rules": []}
            
            config = {"rules": []}
            current_rule = None
            current_class = None
            
            for line in lines[1:]:
                stripped = line.strip()
                if stripped.startswith("- iface:"):
                    if current_rule:
                        config["rules"].append(current_rule)
                    iface = stripped.split(":", 1)[1].strip()
                    current_rule = {"iface": iface, "classes": []}
                elif stripped.startswith("root_rate:") and current_rule:
                    current_rule["root_rate"] = stripped.split(":", 1)[1].strip()
                elif stripped == "classes:" and current_rule:
                    continue  # 跳过类别标记行
                elif stripped.startswith("- classid:") and current_rule:
                    if current_class:
                        current_rule["classes"].append(current_class)
                    classid = stripped.split(":", 1)[1].strip()
                    current_class = {"classid": classid}
                elif stripped.startswith("rate:") and current_class:
                    current_class["rate"] = stripped.split(":", 1)[1].strip()
                elif stripped == "filters:" and current_class:
                    current_class["filters"] = []
                elif stripped.startswith("- port:") and current_class and "filters" in current_class:
                    # 解析端口和协议信息，格式如: "- port: 1334 protocol: tcp"
                    parts = stripped[2:].split()
                    filter_info = {}
                    for i in range(0, len(parts), 2):
                        if i+1 < len(parts):
                            key = parts[i].rstrip(":")
                            value = parts[i+1]
                            filter_info[key] = value
                    if filter_info:
                        current_class["filters"].append(filter_info)
            
            # 添加最后一个规则和类
            if current_class and current_rule:
                current_rule["classes"].append(current_class)
            if current_rule:
                config["rules"].append(current_rule)
                
            return config
    except FileNotFoundError:
        return {"rules": []}

# ---------------- YAML 写入 ----------------

def write_yaml_config(config):
    """将配置对象写入 config.yaml（最新版结构）。成功返回 True，否则 False。"""
    try:
        with open("config.yaml", "w", encoding="utf-8") as f:
            yaml.safe_dump(config, f, sort_keys=False, allow_unicode=True)
        return True
    except Exception as e:
        print(colored(f"[写入配置文件失败] {e}\n", "red"))
        return False

# ---------------- 应用 YAML 配置 (最新版) ----------------

def apply_yaml_config_v2():
    """根据最新 YAML 配置应用限速，支持端口段独立限速。"""
    # 确保 IFB0 可用
    if not ensure_ifb():
        print(colored("[错误] IFB 虚拟网卡工作异常，已中止限速规则应用。\n", "red"))
        return False

    config = read_yaml_config()
    physical_ifaces = get_interfaces()
    success = True

    def parse_name(name: str):
        """解析 name 字段，返回 (start_port, end_port, [protos])"""
        try:
            port_part, proto_part = name.split("@")
        except ValueError:
            raise ValueError(f"name 字段格式错误: {name}")
        proto_part = proto_part.lower()
        protos = ["tcp", "udp"] if proto_part == "tcpudp" else [proto_part]
        if "-" in port_part:
            s, e = map(int, port_part.split("-"))
        else:
            s = e = int(port_part)
        return s, e, protos

    for rule in config.get("rules", []):
        iface = rule.get("iface")
        if iface not in physical_ifaces:
            print(colored(f"[警告] 网卡 {iface} 不存在，跳过", "yellow"))
            success = False
            continue

        root_rate = rule.get("root_rate")
        if not root_rate:
            print(colored(f"[警告] 网卡 {iface} 的 root_rate 未设置，跳过", "yellow"))
            success = False
            continue

        # 入口流量转发至 ifb0
        setup_ingress_redirect(iface)

        for target in [iface, "ifb0"]:
            # ifb0 只初始化一次
            if target == "ifb0" and getattr(apply_yaml_config_v2, "_ifb_inited", False):
                pass
            else:
                if target == "ifb0":
                    apply_yaml_config_v2._ifb_inited = True
                # 清理 root 并重建
                subprocess.run(["tc", "qdisc", "del", "dev", target, "root"], check=False, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                subprocess.run(["tc", "qdisc", "add", "dev", target, "root", "handle", "1:", "htb"], check=False, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                subprocess.run(["tc", "class", "add", "dev", target, "parent", "1:", "classid", "1:1", "htb", "rate", root_rate], check=False, stdout=subprocess.PIPE, stderr=subprocess.PIPE)

            # 遍历子分类
            for cls in rule.get("classes", []):
                try:
                    port_start, port_end, protos = parse_name(cls["name"])
                except Exception as e:
                    print(colored(f"[错误] 解析 name 失败: {e}", "red"))
                    success = False
                    continue

                cid_start = int(cls["classid_group_start"].split(":")[1])
                cid_end = int(cls["classid_group_end"].split(":")[1])
                if cid_end - cid_start != port_end - port_start:
                    print(colored(f"[错误] {cls['name']} 的端口数量与 classid 数不一致", "red"))
                    success = False
                    continue

                rate = cls["rate"]

                for offset, port in enumerate(range(port_start, port_end + 1)):
                    minor_val = cid_start + offset
                    classid = f"1:{minor_val:x}"  # tc 按十六进制解析 classid
                    # 创建/更新 class
                    res = subprocess.run(["tc", "class", "replace", "dev", target, "parent", "1:1", "classid", classid, "htb", "rate", rate],
                                         check=False, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                    if res.returncode != 0:
                        print(colored(f"[错误] 创建/更新分类 {classid} 失败 (dev {target}): {res.stderr.strip()}", "red"))
                        success = False
                    # 创建 filters
                    for proto in protos:
                        proto_num = "6" if proto == "tcp" else "17"
                        for dirflag in ("sport", "dport"):
                            res_f = subprocess.run([
                                "tc", "filter", "add", "dev", target, "protocol", "ip", "parent", "1:0", "prio", "1", "u32",
                                "match", "ip", "protocol", proto_num, "0xff", "match", "ip", dirflag, str(port), "0xffff", "flowid", classid
                            ], check=False, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                            if res_f.returncode != 0:
                                print(colored(f"[错误] 添加过滤器失败 (dev {target} port {port}/{proto} {dirflag}): {res_f.stderr.strip()}", "red"))
                                success = False
            print(colored(f"[{target}] 规则应用完成", "green"))

    return success

# ---------------- IFB 虚拟网卡支持 ----------------

def ensure_ifb():
    """确保 ifb0 虚拟网卡可用并已挂 htb root。返回 bool。"""
    # 若设备不存在则尝试创建
    if not os.path.exists('/sys/class/net/ifb0'):
        subprocess.run(["modprobe", "ifb", "numifbs=1"], check=False, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    # 将 ifb0 置 up
    subprocess.run(["ip", "link", "set", "ifb0", "up"], check=False, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    # 校验 operstate
    state = "unknown"
    try:
        with open('/sys/class/net/ifb0/operstate') as f:
            state = f.read().strip()
    except Exception:
        pass
    if state not in ("up", "unknown"):
        print(colored("[错误] ifb0 接口未处于 UP/UNKNOWN 状态。", "red"))
        return False
    # 确保 root qdisc
    try:
        out = subprocess.check_output(["tc", "qdisc", "show", "dev", "ifb0"], encoding="utf-8")
    except subprocess.CalledProcessError:
        out = ""
    if "htb 1:" not in out:
        subprocess.run(["tc", "qdisc", "del", "dev", "ifb0", "root"], check=False, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        subprocess.run(["tc", "qdisc", "add", "dev", "ifb0", "root", "handle", "1:", "htb"], check=False, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    return True


def setup_ingress_redirect(iface: str):
    """在物理网卡上挂 ingress 并 mirred 到 ifb0。"""
    try:
        qdisc_out = subprocess.check_output(["tc", "qdisc", "show", "dev", iface], encoding="utf-8")
    except subprocess.CalledProcessError:
        qdisc_out = ""
    if "ffff:" not in qdisc_out:
        subprocess.run(["tc", "qdisc", "add", "dev", iface, "handle", "ffff:", "ingress"], check=False, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    try:
        filter_out = subprocess.check_output(["tc", "filter", "show", "dev", iface, "parent", "ffff:"], encoding="utf-8")
    except subprocess.CalledProcessError:
        filter_out = ""
    if "mirred" not in filter_out or "ifb0" not in filter_out:
        subprocess.run(["tc", "filter", "add", "dev", iface, "parent", "ffff:", "protocol", "ip", "prio", "1", "u32",
                        "match", "u32", "0", "0", "action", "mirred", "egress", "redirect", "dev", "ifb0"], check=False,
                       stdout=subprocess.PIPE, stderr=subprocess.PIPE)

# ---------------- 交互式添加子分类 ----------------

def add_tc_limit():
    """交互式添加端口(段)限速子分类，支持 TCP/UDP/TCP+UDP。

    操作步骤：
        1. 选择物理网卡（排除 ifb0）
        2. 录入端口或端口段，例如 1666 或 10000-10010
        3. 选择协议类型
        4. 输入限速速率 (Mbps)

    完成后立即写入 YAML 并调用 apply_yaml_config_v2 生效。
    """

    iface = select_interface(allow_ifb=False)
    if not iface:
        return

    # 读取/初始化配置
    config = read_yaml_config()
    rule = next((r for r in config.get("rules", []) if r.get("iface") == iface), None)
    if not rule:
        print(colored(f"[{iface}] 在配置文件中尚未初始化，请先执行“初始化/重置限速结构”。\n", "yellow"))
        return

    # ---- 端口输入 ----
    while True:
        port_input = input("请输入端口号（单端口或连续段，如 1666 或 10000-10010）：").strip()
        if not port_input:
            print(colored("端口不能为空。\n", "yellow"))
            continue
        try:
            if "-" in port_input:
                p_start, p_end = map(int, port_input.split("-", 1))
                if p_start <= 0 or p_end <= 0 or p_start > 65535 or p_end > 65535 or p_start > p_end:
                    raise ValueError
            else:
                p_start = p_end = int(port_input)
                if p_start <= 0 or p_start > 65535:
                    raise ValueError
            break
        except ValueError:
            print(colored("端口输入不合法，请重新输入。\n", "yellow"))

    # ---- 协议选择 ----
    proto_choice = input("协议选择：1) TCP  2) UDP  3) TCP+UDP (默认 3)：").strip() or "3"
    proto_map = {"1": "tcp", "2": "udp", "3": "tcpudp"}
    if proto_choice not in proto_map:
        print(colored("协议选择无效。\n", "yellow"))
        return
    proto_str = proto_map[proto_choice]

    # ---- 速率输入 ----
    rate_num = input("请输入限速速率（单位 Mbps，只输入数字）：").strip()
    if not rate_num.isdigit() or int(rate_num) <= 0:
        print(colored("限速速率必须为正整数。\n", "yellow"))
        return
    rate_str = f"{rate_num}mbit"

    # ---- 构造并追加配置 ----
    name_field = f"{p_start}-{p_end}@{proto_str}" if p_start != p_end else f"{p_start}@{proto_str}"
    class_cfg = {
        "name": name_field,
        "classid_group_start": f"1:{p_start}",
        "classid_group_end": f"1:{p_end}",
        "rate": rate_str,
    }
    rule.setdefault("classes", []).append(class_cfg)

    # 写入并应用
    if write_yaml_config(config):
        print(colored("配置已写入，正在应用到系统…", "cyan"))
        if apply_yaml_config_v2():
            print(colored(f"[{iface}] 规则 {name_field} 已生效！\n", "green"))
        else:
            print(colored("应用到系统时出错，请检查日志。\n", "red"))
    else:
        print(colored("写入配置文件失败！\n", "red"))


def delete_tc_limit():
    """交互式删除端口限速子分类（根据 name 字段）。"""
    iface = select_interface(allow_ifb=True)
    if not iface:
        return

    config = read_yaml_config()
    rule = next((r for r in config.get("rules", []) if r.get("iface") == iface), None)
    if not rule or not rule.get("classes"):
        print("\n配置文件中未找到该网卡的限速子分类，无法删除。\n")
        return

    # 列出可删除的 name
    names = [c.get("name", "") for c in rule["classes"]]
    print("\n可删除的端口限速规则：")
    for idx, n in enumerate(names, 1):
        print(f"  {idx}. {n}")

    while True:
        sel = input("请输入要删除的规则编号，或直接输入 name：").strip()
        if sel.isdigit() and 1 <= int(sel) <= len(names):
            target_name = names[int(sel) - 1]
            break
        elif sel in names:
            target_name = sel
            break
        else:
            print(colored("无效输入，请重新输入。\n", "yellow"))

    # 执行删除
    before_cnt = len(rule["classes"])
    rule["classes"] = [c for c in rule["classes"] if c.get("name") != target_name]
    after_cnt = len(rule["classes"])
    if after_cnt == before_cnt:
        print("未找到匹配的规则，未做修改。\n")
        return

    # 写回配置
    if write_yaml_config(config):
        print(f"已从配置文件删除规则 {target_name}。正在重新应用限速……")
        if apply_yaml_config_v2():
            print("删除并应用成功！\n")
        else:
            print("规则已从配置删除，但应用到系统时出错，请检查上方日志。\n")
    else:
        print("写入配置文件失败，未删除任何规则。\n")

# ---------------- 配置同步 & 初始化 ----------------

def apply_config_menu():
    """从 YAML 配置应用限速规则到系统 (调用 apply_yaml_config_v2)。"""
    print(colored("\n正在从配置文件应用限速规则…", "cyan"))
    if apply_yaml_config_v2():
        print(colored("配置应用成功！\n", "green"))
    else:
        print(colored("配置应用过程中出现错误，请检查上方日志。\n", "red"))


def sync_tc_config_all_ifaces():
    """将当前系统 tc 配置同步写入 YAML (仅同步已存在的网卡)。"""
    config = read_yaml_config()
    config_ifaces = [r.get("iface") for r in config.get("rules", [])]
    physical_ifaces = get_interfaces()
    if not physical_ifaces:
        print(colored("未检测到物理网卡，无法同步。\n", "red"))
        return False
    if not config_ifaces:
        interfaces_to_sync = physical_ifaces
    else:
        interfaces_to_sync = [i for i in config_ifaces if i in physical_ifaces]
    new_rules = []
    for iface in interfaces_to_sync:
        root_rate = get_root_rate(iface) or "0mbit"
        classes = get_classes(iface)
        new_rules.append({"iface": iface, "root_rate": root_rate, "classes": classes})
    if write_yaml_config({"rules": new_rules}):
        return True
    return False


def sync_config_menu():
    """交互式：从系统同步到 YAML。"""
    print(colored("\n警告：该操作将覆盖配置文件！", "yellow"))
    if input("是否继续同步操作？(y/n): ").strip().lower() != 'y':
        print("操作已取消。\n")
        return
    print(colored("\n正在同步当前系统限速规则到配置文件…", "cyan"))
    if sync_tc_config_all_ifaces():
        print(colored("同步成功！\n", "green"))
    else:
        print(colored("同步失败，请检查日志。\n", "red"))


def init_tc_root():
    """交互式初始化/重置指定网卡总限速 (root_rate)。"""
    iface = select_interface(allow_ifb=False)
    if not iface:
        return
    while True:
        rate_num = input("请输入总限速速率 (Mbps，仅数字)：").strip()
        if rate_num.isdigit() and int(rate_num) > 0:
            break
        print(colored("输入无效，请重新输入正整数。\n", "yellow"))
    rate_str = f"{rate_num}mbit"
    config = read_yaml_config()
    rule = next((r for r in config.get("rules", []) if r.get("iface") == iface), None)
    if not rule:
        rule = {"iface": iface, "classes": []}
        config.setdefault("rules", []).append(rule)
    # 是否清空现有子分类
    if rule.get("classes"):
        keep = input("检测到已有端口限速规则，是否保留？(y/n): ").strip().lower()
        if keep != 'y':
            rule["classes"] = []
            print("已清空现有子分类。")
    rule["root_rate"] = rate_str
    if write_yaml_config(config):
        print(colored("配置已写入，正在应用…", "cyan"))
        if apply_yaml_config_v2():
            print(colored(f"[{iface}] tc 结构已初始化，总限速 {rate_num} Mbps。\n", "green"))
        else:
            print(colored("应用失败，请检查日志。\n", "red"))
    else:
        print(colored("写入配置文件失败！\n", "red"))


def show_tc_rules():
    """查询菜单，提供简易和专业两种模式"""
    print(colored("===== 查询模式选择 =====", "cyan"))
    print("1. 简易查询 (适合非技术用户)")
    print("2. 专业查询 (显示详细技术信息)")
    print("0. 返回上级菜单")
    
    while True:
        choice = input("请选择查询模式：").strip()
        if choice == '1':
            show_tc_rules_simple()
            break
        elif choice == '2':
            show_tc_rules_advanced()
            break
        elif choice == '0':
            break
        else:
            print("无效选择，请重新输入。\n")

def main_menu():
    while True:
        print("\n" + colored("===== 简易限速管理菜单 =====", "cyan"))
        print("1. 查看当前限速 (查询)")
        print("2. 新增端口限速")
        print("3. 删除端口限速")
        print("4. 应用配置到系统")
        print("5. 初始化/重置全部限速")
        print("0. 退出 (Exit)")
        choice = input("请选择操作：").strip()
        if choice == '1':
            show_tc_rules()
        elif choice == '2':
            add_tc_limit()
        elif choice == '3':
            delete_tc_limit()
        elif choice == '4':
            apply_config_menu()
        elif choice == '5':
            init_tc_root()
        elif choice == '0':
            print("已退出脚本。")
            break
        else:
            print("无效选择，请重新输入。\n")

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Linux TC 双向限速脚本")
    parser.add_argument("--apply", action="store_true", help="从 YAML 配置应用限速后退出")
    args = parser.parse_args()

    try:
        if args.apply:
            ok = apply_yaml_config_v2()
            sys.exit(0 if ok else 1)
        # 默认进入交互菜单
        main_menu()
    except KeyboardInterrupt:
        print("\n已收到 Ctrl+C，脚本已退出。")
